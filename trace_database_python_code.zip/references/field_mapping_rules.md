# Field Mapping Rules

`scripts/field_mapper.py` maps arbitrary DOORS-export column headers to a
fixed set of canonical field names using case-insensitive substring matching,
checked in this exact order (first match wins). If you need to support a new
header variant, add a keyword here AND in the `HEADER_RULES` list in
`field_mapper.py` — keep both in sync.

| Canonical field | Matches headers containing (lowercased) | Real examples seen |
|---|---|---|
| `vll` | "verified lower level", "isvll", "vll" | `Verified Lower Level`, `isVLL` |
| `test_proc_name` | "test proc name", "test spec name" | `Test Proc Name`, `Test Spec Name` |
| `test_proc_id` | "test proc id", "test spec id", "tpro" | `Test Proc ID`, `Test Spec ID`, `TPRO` |
| `verification_stage` | "verification stage" | `Verification Stage` |
| `verification_level` | "verification level" | `Verification Level` |
| `verification_method` | "verification method" | `Verification Method` |
| `verification_status` | "verification status" | `Verification Status` |
| `verification_comments` | "verification comment" | `Verification Comments` |
| `vcb_comments` | "vcb comment" | `VCB Comments` |
| `verification_report_ref` | "verification report reference" | `Verification Report Reference` |
| `local_compliance_raw` | "local compliance summary" | `Local Compliance Summary` |
| `ll_closeout_raw` | "ll close-out summary", "ll close out summary" | `LL Close-Out Summary` |
| `closeout_status` | "close-out status", "close out status" | `Close-Out Status` |
| `compliance_status` | "dxl_compliance_status", "compliance status" | `Compliance Status`, `DXL_Compliance_Status` |
| `uptrace_raw` | "dxl_uptrace", "uptrace" | `DXL_Uptrace` |
| `object_level` | "object level" | `Object Level` |
| `absolute_number` | "absolute number" | `Absolute Number` |
| `req_text` | "#req. info", "req. info", "requirements" | `#Req. Info`, `Requirements` |
| `req_id` | "req. id", "req id" | `Req. ID` |

## Ignored headers (deliberate noise)

These substrings cause a header to be skipped entirely, never mapped:
`:noexport`, `rfd/rfw`, `mbse-334`, `stage@tranchelevel`.

## Known duplicate-header situations (real, not hypothetical)

- **Duplicate "Req. ID" columns**: some modules export TWO columns both
  literally named "Req. ID" — one carries a DOORS version suffix like
  `GS-SYS-00010 (v2A)`, the other is the clean ID `GS-SYS-00010` used in all
  cross-references. `pick_req_id_value()` in `field_mapper.py` prefers the
  column WITHOUT a `(...)` suffix; if all candidates have a suffix, it
  strips the suffix from the first one via `strip_version_suffix()`.
- **Duplicate "Test Proc ID" columns**: same idea — keep the first non-empty
  value found, since duplicate columns are usually two export passes of the
  same underlying attribute.

## Adding a new header variant

1. Find the exact header text in the new file (open it and check row 1).
2. Add a short lowercase keyword (avoid overly generic words like "status"
   alone, since that would match too many unrelated headers — be specific,
   e.g. "compliance status" not "status").
3. Add it to the matching `HEADER_RULES` tuple in `field_mapper.py`, in the
   most specific-appropriate position (more specific rules must stay above
   more general ones, since the first match wins).
4. Re-run the pipeline and check `Load_Log` sheet's "Unrecognized Columns"
   section — it should no longer list that header.

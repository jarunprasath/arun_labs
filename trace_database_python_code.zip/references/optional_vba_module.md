# Optional VBA Module (self-import)

Claude cannot safely author a binary `.xlsm` VBA project in this
environment (see SKILL.md "Why no VBA / .xlsm macros"). Instead, here is a
plain-text VBA module the person can import into their OWN Excel in about
30 seconds, giving them a one-click Refresh button and a Drilldown helper.

## Import steps (for the person, in Excel)

1. Open the generated `Master_Trace_Database.xlsx`.
2. Save As -> choose **Excel Macro-Enabled Workbook (*.xlsm)**.
3. Press `Alt+F11` to open the VBA editor.
4. Right-click the workbook in the Project pane -> `Insert` -> `Module`.
5. Paste the code from `scripts/TraceDatabaseMacros.bas` (or copy it below)
   into the new module.
6. Close the VBA editor, save the `.xlsm`.
7. On the `Dashboard` sheet, insert a shape/button (Insert -> Shapes), right
   click it -> `Assign Macro` -> pick `RefreshTraceDatabase` or
   `JumpToReqID`.

## What the macros do

- **`RefreshTraceDatabase`**: shells out to run
  `python build_workbook.py <folder> <this_file>` using the folder path
  typed into a cell on the Dashboard, then prompts the person to re-open the
  file (Excel cannot safely reload its own open file out from under itself,
  so this opens the regenerated file as a new window instead — standard
  practice for this kind of refresh-via-external-script pattern).
- **`JumpToReqID`**: prompts for a Req ID, writes it into the `Search` sheet
  dropdown cell, and activates that sheet — a faster alternative to manually
  clicking the dropdown.

## VBA source

```vba
Option Explicit

Sub RefreshTraceDatabase()
    Dim pythonPath As String
    Dim scriptPath As String
    Dim inputFolder As String
    Dim outputPath As String
    Dim cmd As String

    pythonPath = InputBox("Path to python executable:", "Refresh Trace Database", "python")
    scriptPath = InputBox("Full path to build_workbook.py:", "Refresh Trace Database")
    inputFolder = InputBox("Full path to your requirements input folder:", "Refresh Trace Database")
    outputPath = ThisWorkbook.FullName

    If scriptPath = "" Or inputFolder = "" Then
        MsgBox "Refresh cancelled — missing script or folder path.", vbExclamation
        Exit Sub
    End If

    cmd = """" & pythonPath & """ """ & scriptPath & """ """ & inputFolder & """ """ & outputPath & """"

    MsgBox "About to run:" & vbCrLf & cmd & vbCrLf & vbCrLf & _
           "Close this workbook first if you want the script to overwrite it cleanly.", vbInformation

    Shell "cmd.exe /c " & cmd, vbNormalFocus

    MsgBox "Refresh launched in a command window. Once it finishes, close and reopen this file.", vbInformation
End Sub

Sub JumpToReqID()
    Dim reqId As String
    reqId = InputBox("Enter the Req. ID to look up:", "Jump to Requirement")
    If reqId = "" Then Exit Sub

    ThisWorkbook.Sheets("Search").Range("B4").Value = reqId
    ThisWorkbook.Sheets("Search").Activate
    ThisWorkbook.Sheets("Search").Range("B4").Select
End Sub
```

## Why this is the safer path

This code is plain text the person reads, pastes, and compiles themselves
inside their own trusted Excel install — they can see exactly what it does
before running it (it only shells a python command they typed and writes a
cell value; nothing hidden). That is meaningfully different from Claude
shipping an opaque pre-compiled `vbaProject.bin` binary that nobody —
including Claude — can inspect or verify before it runs.

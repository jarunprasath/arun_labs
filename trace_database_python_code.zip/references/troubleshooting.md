# Troubleshooting

## "DUPLICATE Req ID 'X' also in file Y" appears in Load_Log
Two different source files contain a row for the same Req ID. The pipeline
keeps the FIRST occurrence found (by file discovery order, which is
alphabetical by filename) and logs the conflict — it does NOT merge or
overwrite. If the two rows actually differ (e.g. one is stale), tell the
person which file's row was kept and let them decide whether to remove the
stale file from the input folder and re-run.

## A column you expect to see data from is empty in Master_Trace
1. Check `Load_Log` -> "Unrecognized Columns" for that file/sheet — the
   header text probably isn't matched by any rule yet. Add a keyword (see
   `field_mapping_rules.md`).
2. If the header IS recognized but values still look empty, check whether
   the column has TWO matches in the same sheet (e.g. two "Req. ID"
   columns) and the wrong one is winning by `extract_row_fields`'s
   first-non-empty rule. Open the raw file with openpyxl and print every
   column to see what's actually there.

## recalc.py reports `#NAME?` errors
This means a formula uses a function LibreOffice's installed version
doesn't recognize — almost always a dynamic-array function (`FILTER`,
`HSTACK`, `UNIQUE`, etc.). **Do not use these in this skill's output** —
they're inconsistent across Excel/LibreOffice versions and the person's own
Excel version is unknown. The Search sheet's filter is deliberately built
with classic helper-column + `INDEX`/`MATCH`/`SMALL`/`SUMPRODUCT`-style
formulas instead, which work in every Excel version since 2007. If you add
a new formula feature, stick to this classic-formula constraint.

## recalc.py reports `#REF!` or `#VALUE!` in the Search sheet
Almost always a cross-sheet reference missing its sheet-name prefix (e.g. a
formula written onto `Master_Trace` referencing `$B$28` when it actually
means `Search!$B$28`). Every cross-sheet formula MUST explicitly qualify the
sheet name on every reference to a cell outside its own sheet — Excel does
NOT infer the "calling" sheet's cell when a formula lives on a different
sheet than the one it's displayed on (in this codebase, helper-column
formulas live on `Master_Trace` but read the filter box from `Search`, so
they need `Search!$B$<row>`, not just `$B$<row>`).

## A requirement shows as "External / Not Loaded" but I uploaded its file
1. Check the Req ID actually used in the file vs. the Req ID referenced
   elsewhere — DOORS version suffixes like `(v2A)` must be stripped for the
   IDs to match. Check `strip_version_suffix()` is being applied to BOTH the
   defining row's ID and any version-suffixed reference (in practice,
   references in `DXL_Uptrace`/`LL Close-Out Summary` text don't carry
   version suffixes, but always verify on new data).
2. Check the file actually loaded without error in `Load_Log`.
3. Check for whitespace or punctuation mismatches (e.g. a trailing space,
   or `GS-SYS-00120` vs `GS-SYS-0120` typo in the source data itself — this
   does happen in real DOORS exports and is worth flagging to the person
   rather than silently working around).

## Effective status seems wrong for a VLL=Yes requirement
Re-read the VLL business rule in SKILL.md rule #1. Specifically: a single
missing child anywhere in the (recursive) descendant tree should force
"Open - Pending Data", not a confident "Closed". If you see a false
"Closed", check `has_missing_descendant` propagation in
`compute_effective_status()` — it must propagate through children/memoized
nodes, not just direct children.

## The workbook opens but the Search dropdown doesn't show entries
The `DataValidation` list formula points at `Master_Trace!$A$<first_data_row>:$A$<last_row>`.
If `Master_Trace` was resorted or rows were inserted/deleted manually after
generation, the range will be stale. Always re-run the generator from
source rather than hand-editing `Master_Trace` row order.

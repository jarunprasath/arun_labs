# Validation Checklist (run before delivering the workbook)

A fuzzy header mapper can silently misfire — it will not raise an error if
it maps the wrong column or misses one. Always do these checks before
calling `present_files`:

## 1. Check the Load_Log sheet
- Every source file should show `status: OK` with a non-zero `rows_loaded`
  count roughly matching the number of requirement rows you'd expect from
  that file (open the source file and count Req-ID-bearing rows yourself if
  unsure).
- `SKIPPED - no Req ID column detected` means the fuzzy mapper failed to
  find a Req ID column in that sheet — almost always means a header text
  variant isn't in `field_mapping_rules.md` yet. Fix and re-run.
- Check "Unrecognized Columns" — if something that looks important (e.g. a
  status-bearing column) appears there, the field mapper missed it; add the
  keyword per `field_mapping_rules.md`.

## 2. Hand-verify 2-3 requirements end-to-end
Pick one requirement from each loaded module and manually trace it:
1. Open the original source `.xlsx`, find the row, read its
   `LL Close-Out Summary` and `DXL_Uptrace` cells directly.
2. Open the generated `Master_Trace` sheet, find the same Req ID.
3. Confirm: `# Direct Children` matches the count of `[Module] ReqID: '...'`
   lines in the source cell (excluding the header-echo line and any indented
   sub-detail lines without a `[Module]` prefix).
4. Confirm: `Parent Req IDs` matches the `DXL_Uptrace` cell content.
5. Confirm: the `Reason / Explanation` text is sensible given the VLL flag
   and own Close-Out Status you see in the source row.

## 3. Check the Dashboard counts add up
`Total requirements referenced` should equal `loaded` + `missing`. The sum
of the five effective-status counts should equal the total.

## 4. Re-run recalc.py and confirm zero errors
```bash
python3 scripts/recalc.py <output_xlsx_path> 60
```
Expect `"status": "success", "total_errors": 0`. If errors appear, see
`troubleshooting.md`.

## 5. Spot-check the Search sheet
Open the file, type a known Req ID into the dropdown cell, and confirm the
card below populates correctly (do this by setting the cell value via
openpyxl and recalculating — see `build_workbook.py`'s own test pattern if
you need an example).

## 6. Sense-check "Open - Pending Data" vs "Open"
A requirement should only show "Open - Pending Data" if VLL/isVLL = Yes AND
at least one child is missing. If you see this status on a VLL=No
requirement, something is wrong in `trace_engine.py` — that combination
should never occur for VLL=No requirements (those always resolve to
`OPEN`/`CLOSED`/`UNVERIFIED` based on their own Close-Out Status).

"""
ingest.py
Discovers and loads ALL .xlsx requirement-module files in a folder (any
filename -- per user preference, filenames are NOT relied upon for module
identity; module identity comes from the [Module] tags embedded in the
DXL_Uptrace / LL Close-Out Summary text, or from the source filename only
as a last-resort fallback label).

Produces a flat registry: req_id -> RequirementRecord
"""

import os
import glob
from dataclasses import dataclass, field
from typing import Optional

import openpyxl

from field_mapper import (
    build_column_map, extract_row_fields, pick_req_id_value,
    detect_req_id_column_by_content, extract_req_id_from_cell,
)
from text_parsers import (
    parse_uptrace_block, parse_closeout_block, parse_vll,
    normalize_compliance, normalize_closeout,
)


@dataclass
class RequirementRecord:
    req_id: str
    req_text: Optional[str] = None
    source_file: Optional[str] = None
    source_sheet: Optional[str] = None
    source_row: Optional[int] = None

    compliance_status: Optional[str] = None       # own current compliance code, e.g. 'C','PC','CS'
    closeout_status: str = "UNSET"                  # OPEN / CLOSED / UNSET
    vll: Optional[bool] = None                       # Verified Lower Level flag

    verification_stage: Optional[str] = None
    verification_level: Optional[str] = None
    verification_method: Optional[str] = None
    verification_status: Optional[str] = None
    test_proc_id: Optional[str] = None
    test_proc_name: Optional[str] = None
    absolute_number: Optional[str] = None
    verification_comments: Optional[str] = None
    vcb_comments: Optional[str] = None
    verification_report_ref: Optional[str] = None
    object_level: Optional[str] = None

    parents: list = field(default_factory=list)   # [{"module":..,"req_id":..}]
    # children as recorded in THIS requirement's own LL Close-Out Summary text
    # (a cached snapshot of child status at the time this row was exported)
    children_snapshot: list = field(default_factory=list)

    found: bool = True   # False => this req_id was referenced but never loaded (EXTERNAL/MISSING)


def discover_files(folder):
    return sorted(glob.glob(os.path.join(folder, "**", "*.xlsx"), recursive=True))


def load_folder(folder):
    """
    Load every .xlsx file in `folder` (recursively). Returns:
        registry: dict req_id -> RequirementRecord (found=True)
        load_log: list of dicts describing what was loaded from each file/sheet
        unmapped_headers: dict (file, sheet) -> list of (col_idx, header_text)
    """
    registry = {}
    load_log = []
    unmapped_headers = {}

    files = discover_files(folder)
    for filepath in files:
        fname = os.path.basename(filepath)
        try:
            wb = openpyxl.load_workbook(filepath, data_only=True)
        except Exception as e:
            load_log.append({"file": fname, "sheet": None, "status": f"FAILED TO OPEN: {e}", "rows_loaded": 0})
            continue

        for sheet_name in wb.sheetnames:
            ws = wb[sheet_name]
            header_row = [c.value for c in ws[1]]
            mapping, unmapped = build_column_map(header_row)
            unmapped_headers[(fname, sheet_name)] = unmapped

            # Read all rows once (used for content-based detection and loading).
            all_rows = [[c.value for c in ws[r]] for r in range(1, ws.max_row + 1)]

            content_req_col = None  # 0-based column index if detected by content
            if "req_id" not in mapping:
                content_req_col = detect_req_id_column_by_content(all_rows)
                if content_req_col is None:
                    load_log.append({
                        "file": fname, "sheet": sheet_name,
                        "status": "SKIPPED - no Req ID column detected (no matching header "
                                   "and no column whose cells look like requirement IDs)",
                        "rows_loaded": 0,
                    })
                    continue
                else:
                    hdr_txt = header_row[content_req_col] if content_req_col < len(header_row) else "(blank)"
                    load_log.append({
                        "file": fname, "sheet": sheet_name,
                        "status": f"Req ID column inferred from content at column "
                                   f"{content_req_col + 1} (header was '{hdr_txt}')",
                        "rows_loaded": 0,
                    })

            rows_loaded = 0
            for row_idx in range(2, ws.max_row + 1):
                row_values = [c.value for c in ws[row_idx]]
                if all(v is None for v in row_values):
                    continue

                fields = extract_row_fields(header_row, row_values)

                embedded_text = None
                if content_req_col is not None:
                    # No header-based Req ID: pull it (and any embedded text) from the detected column
                    raw_cell = row_values[content_req_col] if content_req_col < len(row_values) else None
                    req_id, embedded_text = extract_req_id_from_cell(raw_cell)
                else:
                    req_id = fields.get("req_id")

                if not req_id:
                    continue
                # Skip DOORS section heading rows like "§ 3.1" that have no real ID
                if req_id.strip().startswith("§"):
                    continue

                rec = registry.get(req_id)
                if rec is None:
                    rec = RequirementRecord(req_id=req_id)
                    registry[req_id] = rec
                elif rec.found and rec.source_file:
                    # Duplicate Req ID found in another file -- keep first, log conflict
                    load_log.append({
                        "file": fname, "sheet": sheet_name,
                        "status": f"DUPLICATE Req ID '{req_id}' also in {rec.source_file} "
                                   f"(sheet {rec.source_sheet}, row {rec.source_row}) -- kept first occurrence",
                        "rows_loaded": 0,
                    })

                rec.found = True
                rec.source_file = rec.source_file or fname
                rec.source_sheet = rec.source_sheet or sheet_name
                rec.source_row = rec.source_row or row_idx
                rec.req_text = rec.req_text or fields.get("req_text") or embedded_text
                rec.compliance_status = rec.compliance_status or normalize_compliance(fields.get("compliance_status"))
                co = fields.get("closeout_status")
                if co is not None:
                    rec.closeout_status = normalize_closeout(co)
                vll_val = parse_vll(fields.get("vll"))
                if vll_val is not None:
                    rec.vll = vll_val
                rec.verification_stage = rec.verification_stage or fields.get("verification_stage")
                rec.verification_level = rec.verification_level or fields.get("verification_level")
                rec.verification_method = rec.verification_method or fields.get("verification_method")
                rec.verification_status = rec.verification_status or fields.get("verification_status")
                rec.test_proc_id = rec.test_proc_id or fields.get("test_proc_id")
                rec.test_proc_name = rec.test_proc_name or fields.get("test_proc_name")
                rec.absolute_number = rec.absolute_number or fields.get("absolute_number")
                rec.verification_comments = rec.verification_comments or fields.get("verification_comments")
                rec.vcb_comments = rec.vcb_comments or fields.get("vcb_comments")
                rec.verification_report_ref = rec.verification_report_ref or fields.get("verification_report_ref")
                rec.object_level = rec.object_level or fields.get("object_level")

                rec.parents = parse_uptrace_block(fields.get("uptrace_raw"))
                closeout_block = parse_closeout_block(fields.get("ll_closeout_raw"))
                rec.children_snapshot = closeout_block["children"]

                rows_loaded += 1

            load_log.append({
                "file": fname, "sheet": sheet_name,
                "status": "OK", "rows_loaded": rows_loaded,
            })

    return registry, load_log, unmapped_headers


def link_external_references(registry):
    """
    For every child/parent reference that points to a req_id NOT in the
    registry, create a placeholder RequirementRecord with found=False
    (EXTERNAL/MISSING). Returns the same registry, mutated in place, plus a
    list of (referencing_req_id, missing_req_id, module_tag) tuples.
    """
    missing_refs = []
    additions = {}

    for req_id, rec in list(registry.items()):
        for child in rec.children_snapshot:
            cid = child["req_id"]
            if cid not in registry and cid not in additions:
                additions[cid] = RequirementRecord(req_id=cid, found=False)
                missing_refs.append((req_id, cid, child["module"]))
        for parent in rec.parents:
            pid = parent["req_id"]
            if pid not in registry and pid not in additions:
                additions[pid] = RequirementRecord(req_id=pid, found=False)
                missing_refs.append((req_id, pid, parent["module"]))

    registry.update(additions)
    return registry, missing_refs

"""
text_parsers.py
Parses the two critical free-text DOORS export blocks:

1. DXL_Uptrace  -- lines like "[EURD] SYS-00020" => parent requirement links
2. LL Close-Out Summary -- lines like "[OGSRD] GS-SYS-00120: 'PC', 'OPEN'"
   => child requirement links with the child's own compliance/close-out status
      AS RECORDED AT THIS PARENT (this is a cached/denormalized snapshot from
      DOORS; the authoritative status is whatever the child's own row says in
      its source module, when we have that module loaded).

Also normalizes compliance status codes and close-out status text into a
fixed vocabulary used throughout the trace database.
"""

import re

# A child/parent link line: optional leading whitespace, [Module Name] ReqID: 'status', 'closeout'
# The trailing status pair is optional (DXL_Uptrace lines have no trailing status).
LINK_LINE_RE = re.compile(
    r"^\s*\[([^\]]+)\]\s+(\S+?):?\s*(?:'([^']*)'\s*,\s*'([^']*)')?\s*$"
)

# Stricter version used only for LL Close-Out Summary lines, which always have
# a colon followed by two quoted values. This avoids false-matching indented
# "Stage:" sub-detail lines that have no [Module] prefix.
CLOSEOUT_LINE_RE = re.compile(
    r"^\s*\[([^\]]+)\]\s+(\S+):\s*'([^']*)'\s*,\s*'([^']*)'\s*$"
)

UPTRACE_LINE_RE = re.compile(r"^\s*\[([^\]]+)\]\s+(\S+)\s*$")

# Canonical compliance status vocabulary observed in real exports.
COMPLIANCE_LABELS = {
    "C": "Compliant",
    "PC": "Partially Compliant",
    "CS": "Compliant for Stage",
    "NC": "Non-Compliant",
    "NA": "Not Applicable",
    "-": "Unset",
    "": "Unset",
}


def normalize_compliance(value):
    if value is None:
        return None
    v = str(value).strip().upper()
    if v in ("", "-", "NONE"):
        return None
    return v


def compliance_label(code):
    if code is None:
        return "Unset"
    return COMPLIANCE_LABELS.get(code.upper(), code)


def normalize_closeout(value):
    """Normalize close-out status text to OPEN / CLOSED / UNSET."""
    if value is None:
        return "UNSET"
    v = str(value).strip().upper()
    if v in ("", "-", "NONE"):
        return "UNSET"
    if "CLOSE" in v:
        return "CLOSED"
    if "OPEN" in v:
        return "OPEN"
    return v


def parse_uptrace_block(raw_text):
    """
    Parse a DXL_Uptrace cell into a list of dicts:
        [{"module": "EURD", "req_id": "SYS-00020"}, ...]
    Returns [] for empty/None input.
    """
    if not raw_text:
        return []
    results = []
    for line in str(raw_text).splitlines():
        if not line.strip():
            continue
        m = UPTRACE_LINE_RE.match(line)
        if m:
            module, req_id = m.group(1).strip(), m.group(2).strip()
            results.append({"module": module, "req_id": req_id})
    return results


def parse_closeout_block(raw_text):
    """
    Parse an "LL Close-Out Summary" cell.

    Returns a dict:
        {
            "header_status": "Open" | "Closed" | "Closed *" | None,  # first line, before children
            "children": [
                {
                    "module": "OGSRD",
                    "req_id": "GS-SYS-00120",
                    "compliance_status": "PC" or None,
                    "closeout_status": "OPEN" / "CLOSED" / "UNSET",
                },
                ...
            ]
        }

    Lines without a leading "[Module]" prefix (e.g. indented "Stage: '...'"
    sub-detail lines, or the "[MODULE NAME] Req. ID: 'Compliance', 'Close-Out'"
    column-header echo line) are intentionally skipped -- they are not real
    child requirement links.
    """
    result = {"header_status": None, "children": []}
    if not raw_text:
        return result

    lines = str(raw_text).splitlines()
    if lines:
        first = lines[0].strip()
        if first:
            result["header_status"] = first

    for line in lines[1:]:
        if not line.strip():
            continue
        m = CLOSEOUT_LINE_RE.match(line)
        if not m:
            continue
        module, req_id, comp, closeout = m.groups()
        module = module.strip()
        # Skip the column-header echo line DOORS inserts, e.g.
        # "[MODULE NAME] Req. ID: 'Compliance', 'Close-Out'"
        if module.upper() == "MODULE NAME" or req_id.strip().upper().startswith("REQ"):
            continue
        result["children"].append({
            "module": module,
            "req_id": req_id.strip(),
            "compliance_status": normalize_compliance(comp),
            "closeout_status": normalize_closeout(closeout),
        })
    return result


def parse_vll(value):
    """Normalize a Verified Lower Level / isVLL cell to True / False / None."""
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    v = str(value).strip().lower()
    if v in ("yes", "true", "y"):
        return True
    if v in ("no", "false", "n"):
        return False
    return None

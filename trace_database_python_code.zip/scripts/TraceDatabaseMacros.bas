Attribute VB_Name = "TraceDatabaseMacros"
Option Explicit

Sub RefreshTraceDatabase()
    Dim pythonPath As String
    Dim scriptPath As String
    Dim inputFolder As String
    Dim outputPath As String
    Dim cmd As String

    pythonPath = InputBox("Path to python executable:", "Refresh Trace Database", "python")
    scriptPath = InputBox("Full path to build_workbook.py:", "Refresh Trace Database")
    inputFolder = InputBox("Full path to your requirements input folder:", "Refresh Trace Database")
    outputPath = ThisWorkbook.FullName

    If scriptPath = "" Or inputFolder = "" Then
        MsgBox "Refresh cancelled " & Chr(8211) & " missing script or folder path.", vbExclamation
        Exit Sub
    End If

    cmd = """" & pythonPath & """ """ & scriptPath & """ """ & inputFolder & """ """ & outputPath & """"

    MsgBox "About to run:" & vbCrLf & cmd & vbCrLf & vbCrLf & _
           "Close this workbook first if you want the script to overwrite it cleanly.", vbInformation

    Shell "cmd.exe /c " & cmd, vbNormalFocus

    MsgBox "Refresh launched in a command window. Once it finishes, close and reopen this file.", vbInformation
End Sub

Sub JumpToReqID()
    Dim reqId As String
    reqId = InputBox("Enter the Req. ID to look up:", "Jump to Requirement")
    If reqId = "" Then Exit Sub

    ThisWorkbook.Sheets("Search").Range("B4").Value = reqId
    ThisWorkbook.Sheets("Search").Activate
    ThisWorkbook.Sheets("Search").Range("B4").Select
End Sub

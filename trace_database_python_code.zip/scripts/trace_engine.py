"""
trace_engine.py
Builds the full requirement trace tree (parents up, children down) and
computes a rolled-up "effective status" for every requirement according to
the rules the user specified:

  - If Verified Lower Level (VLL) = Yes, the requirement's effective status
    is PURELY a function of its children's status (recursively).
  - If VLL = No (or unset), the requirement's own Compliance/Close-Out Status
    fields are authoritative, but we still surface child status as context
    (a requirement can show "CS" -- compliant for stage -- precisely because
    some, but not all, of its children are closed; this matches the
    SRD_SYS.110 example in the spec).
  - A child reference that points to a requirement never loaded into the
    registry (EXTERNAL/MISSING) makes the status INCONCLUSIVE wherever it
    participates in a VLL=Yes rollup: such a parent is reported as
    "Open/Incomplete - pending data" rather than falsely marked Closed.
  - Cycles (A traces to B traces to A) are detected and broken safely.
"""

from dataclasses import dataclass, field
from typing import Optional


EFFECTIVE_CLOSED = "CLOSED"
EFFECTIVE_OPEN = "OPEN"
EFFECTIVE_PENDING_DATA = "OPEN_PENDING_DATA"     # VLL rollup blocked by missing child data
EFFECTIVE_EXTERNAL = "EXTERNAL_MISSING"           # this req itself was never loaded
EFFECTIVE_UNVERIFIED = "UNVERIFIED"                # no status info at all, not VLL-derived


@dataclass
class TraceNode:
    req_id: str
    effective_status: str = EFFECTIVE_UNVERIFIED
    effective_compliance: Optional[str] = None
    reason: str = ""
    has_missing_descendant: bool = False
    depth_reached: int = 0
    cycle_detected: bool = False


def compute_effective_status(req_id, registry, _visiting=None, _memo=None):
    """
    Recursively compute the effective close-out status for req_id.
    Returns a TraceNode.

    _visiting: set of req_ids currently on the recursion stack (cycle guard)
    _memo: dict req_id -> TraceNode, cache to avoid recomputation
    """
    if _visiting is None:
        _visiting = set()
    if _memo is None:
        _memo = {}

    if req_id in _memo:
        return _memo[req_id]

    rec = registry.get(req_id)
    if rec is None or not rec.found:
        node = TraceNode(
            req_id=req_id,
            effective_status=EFFECTIVE_EXTERNAL,
            effective_compliance=None,
            reason="Requirement not found in any loaded source file (not yet uploaded).",
            has_missing_descendant=True,
        )
        _memo[req_id] = node
        return node

    if req_id in _visiting:
        node = TraceNode(
            req_id=req_id,
            effective_status=EFFECTIVE_OPEN,
            reason="Circular trace reference detected; treated as Open to avoid false closure.",
            cycle_detected=True,
        )
        _memo[req_id] = node
        return node

    _visiting = _visiting | {req_id}

    own_closeout = rec.closeout_status  # OPEN / CLOSED / UNSET
    own_compliance = rec.compliance_status

    if not rec.children_snapshot:
        # Leaf requirement: no recorded children at all. Own status is authoritative.
        if own_closeout == "CLOSED":
            node = TraceNode(req_id, EFFECTIVE_CLOSED, own_compliance,
                              "Leaf requirement; closed based on its own Close-Out Status.")
        elif own_closeout == "OPEN":
            node = TraceNode(req_id, EFFECTIVE_OPEN, own_compliance,
                              "Leaf requirement; open based on its own Close-Out Status.")
        else:
            node = TraceNode(req_id, EFFECTIVE_UNVERIFIED, own_compliance,
                              "Leaf requirement with no Close-Out Status recorded.")
        _memo[req_id] = node
        return node

    child_nodes = []
    for child in rec.children_snapshot:
        cid = child["req_id"]
        cnode = compute_effective_status(cid, registry, _visiting, _memo)
        child_nodes.append((child, cnode))

    any_missing = any(
        cn.effective_status in (EFFECTIVE_EXTERNAL, EFFECTIVE_PENDING_DATA) or cn.has_missing_descendant
        for _, cn in child_nodes
    )
    all_children_closed = all(cn.effective_status == EFFECTIVE_CLOSED for _, cn in child_nodes)
    any_child_open = any(cn.effective_status == EFFECTIVE_OPEN for _, cn in child_nodes)

    if rec.vll is True:
        # Status is PURELY derived from children, per user's stated business rule.
        if any_missing:
            node = TraceNode(
                req_id, EFFECTIVE_PENDING_DATA, own_compliance,
                "Verified Lower Level = Yes, but one or more child requirements are not yet "
                "loaded (external/missing). Cannot confirm full closure -> treated as "
                "Open/Incomplete - pending data.",
                has_missing_descendant=True,
            )
        elif all_children_closed:
            node = TraceNode(
                req_id, EFFECTIVE_CLOSED, own_compliance,
                "Verified Lower Level = Yes and ALL child requirements are Closed.",
            )
        else:
            genuinely_open = [c["req_id"] for c, cn in child_nodes if cn.effective_status == EFFECTIVE_OPEN]
            node = TraceNode(
                req_id, EFFECTIVE_OPEN, own_compliance,
                f"Verified Lower Level = Yes; still Open because child requirement(s) "
                f"{', '.join(genuinely_open) if genuinely_open else 'below'} are not yet Closed.",
            )
    else:
        # VLL = No/unset: own status is authoritative, but we explain WHY using children
        # (mirrors the SRD_SYS.110 'CS' example: status is CS precisely because some, but
        # not all, lower-level requirements are still open).
        if own_closeout == "CLOSED":
            node = TraceNode(req_id, EFFECTIVE_CLOSED, own_compliance,
                              "Closed based on its own Close-Out Status (VLL=No: not purely "
                              "child-derived, but all known children are also closed)."
                              if all_children_closed else
                              "Closed based on its own Close-Out Status, recorded independently "
                              "of lower-level requirement status (VLL=No).")
        elif own_closeout == "OPEN":
            if any_child_open or any_missing:
                genuinely_open = [c["req_id"] for c, cn in child_nodes
                                   if cn.effective_status in (EFFECTIVE_OPEN, EFFECTIVE_PENDING_DATA, EFFECTIVE_UNVERIFIED)]
                missing_ids = [c["req_id"] for c, cn in child_nodes
                               if cn.effective_status == EFFECTIVE_EXTERNAL]
                parts = []
                if genuinely_open:
                    parts.append(f"lower-level requirement(s) still Open: {', '.join(genuinely_open)}")
                if missing_ids:
                    parts.append(f"lower-level requirement(s) not yet loaded (cannot confirm closure): {', '.join(missing_ids)}")
                explanation = "; ".join(parts) if parts else "lower-level requirement status is incomplete"
                node = TraceNode(
                    req_id, EFFECTIVE_OPEN, own_compliance,
                    f"Open. Compliance status '{own_compliance}' reflects partial closure: {explanation}.",
                    has_missing_descendant=any_missing,
                )
            else:
                node = TraceNode(
                    req_id, EFFECTIVE_OPEN, own_compliance,
                    "Open based on its own Close-Out Status, though all currently loaded "
                    "lower-level requirements are Closed (own status not yet updated, or "
                    "additional non-DXL closure activity pending).",
                )
        else:
            node = TraceNode(req_id, EFFECTIVE_UNVERIFIED, own_compliance,
                              "No Close-Out Status recorded at this level.",
                              has_missing_descendant=any_missing)

    node.has_missing_descendant = node.has_missing_descendant or any_missing
    _memo[req_id] = node
    return node


def build_all_trace_nodes(registry):
    """Compute effective status for every requirement in the registry. Returns dict req_id -> TraceNode."""
    memo = {}
    for req_id in registry:
        compute_effective_status(req_id, registry, _memo=memo)
    return memo


def get_descendants(req_id, registry, _seen=None):
    """Flat list of all descendant req_ids (children, grandchildren, ...), depth-first, cycle-safe."""
    if _seen is None:
        _seen = set()
    if req_id in _seen:
        return []
    _seen.add(req_id)
    rec = registry.get(req_id)
    if rec is None or not rec.found:
        return []
    out = []
    for child in rec.children_snapshot:
        cid = child["req_id"]
        out.append(cid)
        out.extend(get_descendants(cid, registry, _seen))
    return out


def get_ancestors(req_id, registry, _seen=None):
    """Flat list of all ancestor req_ids (parents, grandparents, ...), cycle-safe."""
    if _seen is None:
        _seen = set()
    if req_id in _seen:
        return []
    _seen.add(req_id)
    rec = registry.get(req_id)
    if rec is None or not rec.found:
        return []
    out = []
    for parent in rec.parents:
        pid = parent["req_id"]
        out.append(pid)
        out.extend(get_ancestors(pid, registry, _seen))
    return out


def collect_open_descendants(req_id, registry, nodes, _seen=None):
    """
    Walk the full descendant tree of req_id and return a list of dicts for every
    descendant (direct or deep) that is NOT effectively Closed, each carrying:
        req_id, compliance_status, closeout_status (its OWN, from its source row
        if loaded; else the status snapshot recorded at its parent), req_text,
        effective_status, depth, found.
    Cycle-safe. Ordered depth-first so the trace reads top-to-bottom.
    """
    if _seen is None:
        _seen = set()
    results = []
    rec = registry.get(req_id)
    if rec is None or not rec.found:
        return results

    def walk(rid, depth):
        if rid in _seen:
            return
        _seen.add(rid)
        r = registry.get(rid)
        if r is None or not r.found:
            return
        for child in r.children_snapshot:
            cid = child["req_id"]
            cnode = nodes.get(cid)
            crec = registry.get(cid)
            eff = cnode.effective_status if cnode else None
            if eff != EFFECTIVE_CLOSED:
                # Prefer the child's OWN recorded status (authoritative) when the
                # child module is loaded; otherwise fall back to the snapshot the
                # parent recorded in its LL Close-Out Summary text.
                if crec and crec.found:
                    comp = crec.compliance_status
                    closeout = crec.closeout_status
                    text = crec.req_text
                else:
                    comp = child.get("compliance_status")
                    closeout = child.get("closeout_status")
                    text = None
                results.append({
                    "req_id": cid,
                    "compliance_status": comp,
                    "closeout_status": closeout,
                    "req_text": text,
                    "effective_status": eff,
                    "depth": depth,
                    "found": bool(crec and crec.found),
                })
            walk(cid, depth + 1)

    walk(req_id, 1)
    return results


def is_compliant_code(code):
    """True only for a fully-compliant 'C' code (not PC, CS, NC, NS, etc.)."""
    return code is not None and str(code).strip().upper() == "C"


def is_closed_status(status):
    return status is not None and str(status).strip().upper() in ("CLOSED", "CLOSE")


def make_closure_suggestion(req_id, registry, nodes):
    """
    Produce an actionable suggestion string for a requirement, or "" if none.

    Rule (as specified by the user): if a requirement has Verified Lower Level =
    Yes, and its own Compliance Status is not 'C' AND its own Close-Out Status is
    not Closed, BUT all of its (recursively) loaded descendants are effectively
    Closed, then it is a candidate to be promoted to Compliant ('C') and Closed.
    If some descendants are still open or not yet loaded, the suggestion instead
    names what is blocking closure.
    """
    rec = registry.get(req_id)
    if rec is None or not rec.found:
        return ""
    node = nodes.get(req_id)
    if node is None:
        return ""

    own_compliant = is_compliant_code(rec.compliance_status)
    own_closed = is_closed_status(rec.closeout_status)

    if rec.vll is True:
        if own_compliant and own_closed:
            # Already C + Closed on its own. But if VLL=Yes, status should derive
            # from children -- if children are still open or unloaded, that's a
            # conflict worth flagging rather than silently trusting the own status.
            if node.effective_status == EFFECTIVE_CLOSED:
                return ""
            open_kids = collect_open_descendants(req_id, registry, nodes)
            missing = [k["req_id"] for k in open_kids if not k["found"]]
            still_open = [k["req_id"] for k in open_kids if k["found"]]
            parts = []
            if still_open:
                parts.append(f"still-open lower-level req(s): {', '.join(still_open[:15])}")
            if missing:
                parts.append(f"not-yet-loaded lower-level req(s): {', '.join(missing[:15])}")
            if parts:
                return ("Marked Compliant/Closed, but Verified Lower Level = Yes and not all "
                        "lower-level requirements are confirmed Closed -> verify " + "; ".join(parts) +
                        " before relying on this closure.")
            return ""
        if node.effective_status == EFFECTIVE_CLOSED:
            return ("Verified Lower Level = Yes and all lower-level requirements are now "
                    "Closed -> this requirement can be promoted to Compliant ('C') and "
                    "Closed.")
        open_kids = collect_open_descendants(req_id, registry, nodes)
        if not open_kids:
            return ("Verified Lower Level = Yes; no open lower-level requirements remain -> "
                    "this requirement can be set to Compliant ('C') and Closed.")
        missing = [k["req_id"] for k in open_kids if not k["found"]]
        still_open = [k["req_id"] for k in open_kids if k["found"]]
        parts = []
        if still_open:
            parts.append(f"close lower-level req(s): {', '.join(still_open[:15])}")
        if missing:
            parts.append(f"load/verify not-yet-available req(s): {', '.join(missing[:15])}")
        return ("Verified Lower Level = Yes; cannot close yet -> " + "; ".join(parts) + ".")

    # VLL not set / No: only hint if own status is inconsistent with closed children
    if not own_closed and node.effective_status == EFFECTIVE_CLOSED:
        return ("All loaded lower-level requirements are Closed, but this requirement's own "
                "Close-Out Status is not yet Closed -> review whether it can be closed.")
    return ""


def _child_is_closed_for_display(child, registry, nodes):
    """
    Display-classification for the Search-sheet blocks (NOT the rollup logic).
    A child counts as 'closed' for display if:
      - its own module is loaded AND effectively Closed, OR
      - its module is NOT loaded but the parent's LL Close-Out Summary snapshot
        records its close-out as CLOSED (trust the snapshot per user's rule).
    Returns (is_closed, comp, closeout, text, found).
    """
    cid = child["req_id"]
    crec = registry.get(cid)
    cnode = nodes.get(cid)
    if crec and crec.found:
        comp, co, text = crec.compliance_status, crec.closeout_status, crec.req_text
        is_closed = bool(cnode and cnode.effective_status == EFFECTIVE_CLOSED)
        return is_closed, comp, co, text, True
    # Not loaded -> trust the parent's snapshot close-out text
    comp = child.get("compliance_status")
    co = child.get("closeout_status")
    is_closed = (co is not None and str(co).strip().upper() in ("CLOSED", "CLOSE"))
    return is_closed, comp, co, None, False


def collect_closed_direct_children(req_id, registry, nodes):
    """
    Direct (level-1) children of req_id that are Closed for display purposes.
    Closed branches are NOT expanded further. Each dict: req_id,
    compliance_status, closeout_status, req_text, found.
    """
    rec = registry.get(req_id)
    results = []
    if rec is None or not rec.found:
        return results
    for child in rec.children_snapshot:
        is_closed, comp, co, text, found = _child_is_closed_for_display(child, registry, nodes)
        if is_closed:
            results.append({
                "req_id": child["req_id"], "compliance_status": comp,
                "closeout_status": co, "req_text": text, "found": found,
            })
    return results


def collect_pending_descendants_deep(req_id, registry, nodes, _seen=None, _depth=1):
    """
    Recurse DOWN ONLY through not-Closed branches (closed-for-display branches
    are pruned) to surface every pending descendant down to the deepest open
    leaves. Each dict: req_id, compliance_status, closeout_status, req_text,
    effective_status, depth, found, is_deepest_open.
    """
    if _seen is None:
        _seen = set()
    results = []
    rec = registry.get(req_id)
    if rec is None or not rec.found:
        return results

    for child in rec.children_snapshot:
        cid = child["req_id"]
        if cid in _seen:
            continue
        _seen.add(cid)
        is_closed, comp, co, text, found = _child_is_closed_for_display(child, registry, nodes)
        if is_closed:
            continue  # prune closed-for-display branch
        cnode = nodes.get(cid)
        eff = cnode.effective_status if cnode else None
        crec = registry.get(cid)

        # Does this node have any not-closed-for-display children of its own?
        has_open_child = False
        if crec and crec.found:
            for gc in crec.children_snapshot:
                gc_closed, *_ = _child_is_closed_for_display(gc, registry, nodes)
                if not gc_closed:
                    has_open_child = True
                    break

        results.append({
            "req_id": cid, "compliance_status": comp, "closeout_status": co,
            "req_text": text, "effective_status": eff, "depth": _depth,
            "found": found, "is_deepest_open": not has_open_child,
        })
        results.extend(collect_pending_descendants_deep(cid, registry, nodes, _seen, _depth + 1))
    return results


def find_top_level_requirements(registry):
    """
    Candidate 'root' requirements for trace purposes.

    A requirement counts as top-level if it has no parent that is itself
    LOADED (found=True). In real DOORS exports almost every requirement has
    an uptrace to some higher document (EURD, PARD, MOCD...), but if none of
    those parent documents have been loaded into this run, the requirement
    is still the effective top of the trace tree we can actually walk down
    from. As soon as the user loads the parent module, that requirement
    stops being top-level and the real parent takes over.
    """
    roots = []
    for rid, rec in registry.items():
        if not rec.found:
            continue
        loaded_parents = [p for p in rec.parents if registry.get(p["req_id"]) and registry[p["req_id"]].found]
        if not loaded_parents:
            roots.append(rid)
    return roots

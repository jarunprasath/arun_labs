"""
build_workbook.py
Orchestrates the full report: ingestion -> trace computation -> Excel output,
including the formula-driven Search sheet.

Entry point:
    python build_workbook.py <input_folder> <output_xlsx_path>
"""

import sys
import os
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.utils import get_column_letter

from ingest import load_folder, link_external_references
from trace_engine import build_all_trace_nodes, EFFECTIVE_CLOSED, EFFECTIVE_OPEN
from report_builder import (
    build_master_rows, MASTER_COLUMNS, _write_table, build_dashboard,
    build_load_log_sheet, build_missing_refs_sheet, build_trace_chain_sheet,
    build_suggestions_sheet, build_open_descendant_details_sheet,
    FONT_NAME, HEADER_FILL, HEADER_FONT, TITLE_FONT, SUBTITLE_FONT, BASE_FONT, BOLD_FONT,
    _style_header_row, _autosize,
)


def build_search_sheet(wb, master_ws_name, header_row, last_row, ncols):
    """
    A native-Excel search experience:
      - User types/selects a Req ID in a dropdown (data validation sourced from
        the Master_Trace Req ID column).
      - INDEX/MATCH formulas pull every field for that Req ID into a readable
        vertical "card" layout.
      - A second free-text filter box drives a live extract of ALL rows whose
        Effective Status or Req ID contains the typed text, using FILTER().
    """
    ws = wb.create_sheet("Search", 1)
    ws.sheet_view.showGridLines = False

    ws.cell(row=1, column=1, value="Requirement Search & Drilldown").font = TITLE_FONT
    ws.cell(row=2, column=1, value="Pick a Req. ID below to see its full trace details.").font = SUBTITLE_FONT

    ws.cell(row=4, column=1, value="Select Req. ID:").font = BOLD_FONT
    input_cell = "B4"
    ws[input_cell].font = Font(name=FONT_NAME, size=11, bold=True, color="1F4E78")
    ws[input_cell].fill = PatternFill("solid", fgColor="FFF2CC")
    ws[input_cell].border = Border(*[Side(style="thin", color="BF8F00")] * 4)

    req_id_range = f"{master_ws_name}!$A${header_row+1}:$A${last_row}"
    dv = DataValidation(type="list", formula1=f"={req_id_range}", allow_blank=True, showDropDown=False)
    dv.error = "Please pick a Req. ID from the dropdown list."
    dv.prompt = "Start typing or pick from the list"
    ws.add_data_validation(dv)
    dv.add(ws[input_cell])

    from openpyxl.utils import get_column_letter as _gcl
    from report_builder import MASTER_COLUMNS as _MC
    key_to_letter = {key: _gcl(i) for i, (key, _, _) in enumerate(_MC, 1)}

    field_labels = [
        ("Effective Status", key_to_letter["effective_status_label"]),
        ("Loaded?", key_to_letter["found"]),
        ("Compliance Status", key_to_letter["own_compliance_status"]),
        ("Close-Out Status (own)", key_to_letter["own_closeout_status"]),
        ("Verified Lower Level", key_to_letter["vll"]),
        ("Suggested Action", key_to_letter["suggestion"]),
        ("# Direct Children", key_to_letter["num_direct_children"]),
        ("# Total Descendants", key_to_letter["num_descendants"]),
        ("# Open Descendants", key_to_letter["num_open_descendants"]),
        ("# Missing Descendants", key_to_letter["num_missing_descendants"]),
        ("# Parents", key_to_letter["num_parents"]),
        ("Parent Req IDs", key_to_letter["parent_ids"]),
        ("Closed Descendants (direct) [ID | Compliance | Close-Out | Text]", key_to_letter["closed_descendant_details"]),
        ("Open / Pending Descendants (deep) [ID | Compliance | Close-Out | Text]", key_to_letter["pending_descendant_details"]),
        ("Missing/External Descendant Req IDs", key_to_letter["missing_descendant_ids"]),
        ("Reason / Explanation", key_to_letter["reason"]),
        ("Verification Stage", key_to_letter["verification_stage"]),
        ("Verification Method", key_to_letter["verification_method"]),
        ("Test Proc ID", key_to_letter["test_proc_id"]),
        ("Source File", key_to_letter["source_file"]),
        ("Requirement Text", key_to_letter["req_text"]),
        ("Verification Comments", key_to_letter["verification_comments"]),
    ]

    start_row = 6
    for i, (label, master_col_letter) in enumerate(field_labels):
        r = start_row + i
        ws.cell(row=r, column=1, value=label).font = BOLD_FONT
        formula = (
            f'=IFERROR(IF(INDEX({master_ws_name}!${master_col_letter}${header_row+1}:'
            f'${master_col_letter}${last_row},MATCH($B$4,{req_id_range},0))="",""'
            f',INDEX({master_ws_name}!${master_col_letter}${header_row+1}:'
            f'${master_col_letter}${last_row},MATCH($B$4,{req_id_range},0))),"")'
        )
        cell = ws.cell(row=r, column=2, value=formula)
        cell.font = BASE_FONT
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        ws.merge_cells(start_row=r, start_column=2, end_row=r, end_column=6)
        tall_labels = ("Reason / Explanation", "Requirement Text", "Verification Comments",
                       "Suggested Action")
        extra_tall = ("Closed Descendants" in label) or ("Open / Pending Descendants" in label)
        if extra_tall:
            ws.row_dimensions[r].height = 120
        elif label in tall_labels:
            ws.row_dimensions[r].height = 60
        else:
            ws.row_dimensions[r].height = 28

    filter_row = start_row + len(field_labels) + 2
    ws.cell(row=filter_row, column=1, value="Quick text filter (type any text — matches against Req ID, Status, or Compliance):").font = BOLD_FONT
    filter_input_cell = f"B{filter_row}"
    ws[filter_input_cell].fill = PatternFill("solid", fgColor="FFF2CC")
    ws[filter_input_cell].font = Font(name=FONT_NAME, size=11, bold=True)
    ws.cell(row=filter_row + 1, column=1,
            value="Tip: leave blank to see everything, or use the AutoFilter arrows on the "
                  "Master_Trace / Open_Items / Closed_Items sheets for multi-criteria filtering.").font = SUBTITLE_FONT

    result_header_row = filter_row + 3
    headers = ["Req. ID", "Effective Status", "Compliance", "Close-Out", "Reason"]
    for i, h in enumerate(headers, 1):
        ws.cell(row=result_header_row, column=i, value=h)
    _style_header_row(ws, row=result_header_row, ncols=len(headers))

    # Classic-Excel-compatible (no dynamic arrays): a helper column on the
    # Master_Trace sheet flags matching rows, and this block surfaces only
    # matches using SMALL/IFERROR/INDEX -- works in every Excel version.
    n_data_rows = last_row - header_row
    match_col_idx = ncols + 2  # leave one spare column as a gap after the visible table
    match_col_letter = get_column_letter(match_col_idx)
    helper_row_col_idx = match_col_idx + 1
    helper_row_col_letter = get_column_letter(helper_row_col_idx)

    mt = wb[master_ws_name]
    mt.cell(row=header_row, column=match_col_idx, value="SearchMatch").font = Font(name=FONT_NAME, size=8, italic=True, color="999999")
    mt.cell(row=header_row, column=helper_row_col_idx, value="MatchRank").font = Font(name=FONT_NAME, size=8, italic=True, color="999999")
    for r in range(header_row + 1, last_row + 1):
        match_formula = (
            f'=IF(OR(Search!$B${filter_row}="",ISNUMBER(SEARCH(Search!$B${filter_row},$A{r}&$B{r}&$D{r}))),1,0)'
        )
        mt.cell(row=r, column=match_col_idx, value=match_formula).font = Font(name=FONT_NAME, size=8, color="999999")
        rank_formula = f'=IF({match_col_letter}{r}=1,SUM(${match_col_letter}${header_row+1}:{match_col_letter}{r}),"")'
        mt.cell(row=r, column=helper_row_col_idx, value=rank_formula).font = Font(name=FONT_NAME, size=8, color="999999")
    mt.column_dimensions[match_col_letter].width = 4
    mt.column_dimensions[helper_row_col_letter].width = 4

    max_results = 60
    for i in range(max_results):
        r = result_header_row + 1 + i
        rank = i + 1
        row_lookup = (
            f'IFERROR(MATCH({rank},{master_ws_name}!${helper_row_col_letter}${header_row+1}:'
            f'${helper_row_col_letter}${last_row},0)+{header_row},"")'
        )
        for col_offset, src_col_letter in enumerate(["A", "B", "D", "E", "O"], 0):
            cell_formula = (
                f'=IFERROR(IF(INDEX({master_ws_name}!${src_col_letter}:${src_col_letter},{row_lookup})="","",'
                f'INDEX({master_ws_name}!${src_col_letter}:${src_col_letter},{row_lookup})),"")'
            )
            c = ws.cell(row=r, column=col_offset + 1, value=cell_formula)
            c.font = BASE_FONT
            c.alignment = Alignment(wrap_text=(col_offset == 4), vertical="top")

    ws.column_dimensions["A"].width = 32
    for col in "BCDEFGHIJKLMNOPQRSTUVWXYZ":
        ws.column_dimensions[col].width = 16
    ws.column_dimensions["O"].width = 55

    return ws


def build_master_sheet(wb, rows):
    ws, header_row, last_row = _write_table(
        wb, "Master_Trace", rows, MASTER_COLUMNS,
        title="Master Trace Database — every requirement, every level",
    )
    return ws, header_row, last_row


def build_open_closed_sheets(wb, rows):
    open_rows = [r for r in rows if r["effective_status_key"] not in (
        "CLOSED",
    )]
    closed_rows = [r for r in rows if r["effective_status_key"] == "CLOSED"]
    _write_table(wb, "Open_Items", open_rows, MASTER_COLUMNS,
                 title="Open Requirements — what's pending and why")
    _write_table(wb, "Closed_Items", closed_rows, MASTER_COLUMNS,
                 title="Closed Requirements — full trace to closure")


def generate_workbook(input_folder, output_path):
    registry, load_log, unmapped_headers = load_folder(input_folder)
    registry, missing_refs = link_external_references(registry)
    nodes = build_all_trace_nodes(registry)
    rows = build_master_rows(registry, nodes)

    wb = Workbook()
    wb.remove(wb.active)

    build_dashboard(wb, registry, nodes, load_log, missing_refs)
    master_ws, header_row, last_row = build_master_sheet(wb, rows)
    build_search_sheet(wb, "Master_Trace", header_row, last_row, len(MASTER_COLUMNS))
    build_open_closed_sheets(wb, rows)
    build_suggestions_sheet(wb, registry, nodes)
    build_open_descendant_details_sheet(wb, registry, nodes)
    build_trace_chain_sheet(wb, registry, nodes)
    build_missing_refs_sheet(wb, missing_refs)
    build_load_log_sheet(wb, load_log, unmapped_headers, missing_refs)

    wb.active = 0
    out_dir = os.path.dirname(output_path)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)
    wb.save(output_path)

    return {
        "total_requirements": len(registry),
        "loaded": sum(1 for r in registry.values() if r.found),
        "missing": sum(1 for r in registry.values() if not r.found),
        "output_path": output_path,
    }


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python build_workbook.py <input_folder> <output_xlsx_path>")
        sys.exit(1)
    result = generate_workbook(sys.argv[1], sys.argv[2])
    print(result)

"""
report_builder.py
Builds the multi-sheet "Master Trace Database" workbook from a loaded
registry + computed trace nodes.

Sheets produced:
  Dashboard          - high-level counts, charts-ready summary table
  Master_Trace       - one row per requirement, full flattened trace info
  Open_Items         - filtered view: everything not effectively Closed
  Closed_Items       - filtered view: everything effectively Closed
  Search             - data-validation driven single-requirement lookup
  Trace_Chain        - one row per (ancestor->descendant) edge, full depth
  Load_Log           - which files/sheets were read, row counts, warnings
  Missing_Refs       - every EXTERNAL/MISSING requirement and who references it
  _Config            - hidden sheet holding raw data the Search sheet formulas key off
"""

import os
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.formatting.rule import CellIsRule, FormulaRule

from trace_engine import (
    get_descendants, get_ancestors, find_top_level_requirements,
    collect_open_descendants, make_closure_suggestion,
    collect_closed_direct_children, collect_pending_descendants_deep,
    EFFECTIVE_CLOSED, EFFECTIVE_OPEN, EFFECTIVE_PENDING_DATA,
    EFFECTIVE_EXTERNAL, EFFECTIVE_UNVERIFIED,
)

FONT_NAME = "Calibri"
HEADER_FILL = PatternFill("solid", fgColor="1F4E78")
HEADER_FONT = Font(name=FONT_NAME, bold=True, color="FFFFFF", size=10)
TITLE_FONT = Font(name=FONT_NAME, bold=True, size=14, color="1F4E78")
SUBTITLE_FONT = Font(name=FONT_NAME, italic=True, size=9, color="666666")
BASE_FONT = Font(name=FONT_NAME, size=10)
BOLD_FONT = Font(name=FONT_NAME, size=10, bold=True)

STATUS_COLORS = {
    EFFECTIVE_CLOSED: "C6EFCE",          # green
    EFFECTIVE_OPEN: "FFC7CE",            # red
    EFFECTIVE_PENDING_DATA: "FFEB9C",    # amber
    EFFECTIVE_EXTERNAL: "D9D9D9",        # grey
    EFFECTIVE_UNVERIFIED: "D9D9D9",
}
STATUS_FONT_COLORS = {
    EFFECTIVE_CLOSED: "006100",
    EFFECTIVE_OPEN: "9C0006",
    EFFECTIVE_PENDING_DATA: "9C6500",
    EFFECTIVE_EXTERNAL: "595959",
    EFFECTIVE_UNVERIFIED: "595959",
}
STATUS_LABELS = {
    EFFECTIVE_CLOSED: "Closed",
    EFFECTIVE_OPEN: "Open",
    EFFECTIVE_PENDING_DATA: "Open - Pending Data",
    EFFECTIVE_EXTERNAL: "External / Not Loaded",
    EFFECTIVE_UNVERIFIED: "Unverified",
}

THIN_BORDER = Border(bottom=Side(style="thin", color="D0D0D0"))


def _style_header_row(ws, row=1, ncols=None):
    ncols = ncols or ws.max_column
    for col in range(1, ncols + 1):
        c = ws.cell(row=row, column=col)
        c.font = HEADER_FONT
        c.fill = HEADER_FILL
        c.alignment = Alignment(vertical="center", wrap_text=True)
    ws.row_dimensions[row].height = 28
    ws.freeze_panes = ws.cell(row=row + 1, column=1).coordinate


def _autosize(ws, widths):
    for col_idx, width in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(col_idx)].width = width


def _status_fill_font(status_key):
    fill = PatternFill("solid", fgColor=STATUS_COLORS.get(status_key, "FFFFFF"))
    font = Font(name=FONT_NAME, size=10, bold=True, color=STATUS_FONT_COLORS.get(status_key, "000000"))
    return fill, font


def build_master_rows(registry, nodes):
    """Build the flattened row data shared by Master_Trace / Open_Items / Closed_Items."""
    rows = []
    for req_id, rec in sorted(registry.items()):
        node = nodes[req_id]
        ancestors = get_ancestors(req_id, registry) if rec.found else []
        descendants = get_descendants(req_id, registry) if rec.found else []
        open_descendants = [d for d in descendants if nodes.get(d) and nodes[d].effective_status == EFFECTIVE_OPEN]
        missing_descendants = [d for d in descendants if nodes.get(d) and nodes[d].effective_status == EFFECTIVE_EXTERNAL]

        # All pending descendants (deep, snapshot-trusting) with text + status,
        # as "ReqID | Compliance | Close-Out | text" lines for the quick-view column.
        open_details = collect_pending_descendants_deep(req_id, registry, nodes) if rec.found else []
        detail_lines = []
        for d in open_details:
            comp = d["compliance_status"] or "-"
            co = d["closeout_status"] or "-"
            txt = (d["req_text"] or "").strip().replace("\n", " ")
            if len(txt) > 200:
                txt = txt[:200] + "..."
            loaded_flag = "" if d["found"] else "  [not loaded]"
            line = f"{d['req_id']} | {comp} | {co}{loaded_flag}"
            if txt:
                line += f"\n    {txt}"
            detail_lines.append(line)
        open_descendant_details = "\n".join(detail_lines)

        suggestion = make_closure_suggestion(req_id, registry, nodes) if rec.found else ""

        # Closed (direct, snapshot-trusted) and Pending (deep) descendant blocks
        # used by the Search sheet. Stored as stacked text the Search card reads.
        closed_block = collect_closed_direct_children(req_id, registry, nodes) if rec.found else []
        pending_block = collect_pending_descendants_deep(req_id, registry, nodes) if rec.found else []

        def _fmt_descendant(d, indent=False, deepest=False):
            comp = d.get("compliance_status") or "-"
            co = d.get("closeout_status") or "-"
            tag = "" if d.get("found", True) else " (per parent, module not loaded)"
            mark = "  <-- pending closure" if deepest else ""
            lead = ("   " * (d.get("depth", 1) - 1)) if indent else ""
            txt = (d.get("req_text") or "").strip().replace("\n", " ")
            if len(txt) > 180:
                txt = txt[:180] + "..."
            line = f"{lead}{d['req_id']} | {comp} | {co}{tag}{mark}"
            if txt:
                line += f"\n{lead}    {txt}"
            return line

        closed_descendant_details = "\n".join(_fmt_descendant(d) for d in closed_block)
        pending_descendant_details = "\n".join(
            _fmt_descendant(d, indent=True, deepest=d.get("is_deepest_open"))
            for d in pending_block
        )

        rows.append({
            "req_id": req_id,
            "found": rec.found,
            "req_text": (rec.req_text or "")[:500] if rec.found else "(not loaded - referenced only)",
            "source_file": rec.source_file or "",
            "source_sheet": rec.source_sheet or "",
            "source_row": rec.source_row or "",
            "own_compliance_status": rec.compliance_status or "",
            "own_closeout_status": rec.closeout_status if rec.found else "",
            "vll": "Yes" if rec.vll is True else ("No" if rec.vll is False else ""),
            "verification_stage": rec.verification_stage or "",
            "verification_method": rec.verification_method or "",
            "verification_status": rec.verification_status or "",
            "test_proc_id": rec.test_proc_id or "",
            "effective_status_key": node.effective_status,
            "effective_status_label": STATUS_LABELS.get(node.effective_status, node.effective_status),
            "effective_compliance": node.effective_compliance or "",
            "reason": node.reason,
            "suggestion": suggestion,
            "num_direct_children": len(rec.children_snapshot) if rec.found else 0,
            "num_descendants": len(descendants),
            "num_open_descendants": len(open_descendants),
            "num_missing_descendants": len(missing_descendants),
            "open_descendant_ids": ", ".join(open_descendants[:30]) + (" ..." if len(open_descendants) > 30 else ""),
            "open_descendant_details": open_descendant_details,
            "closed_descendant_details": closed_descendant_details,
            "pending_descendant_details": pending_descendant_details,
            "missing_descendant_ids": ", ".join(missing_descendants[:30]) + (" ..." if len(missing_descendants) > 30 else ""),
            "num_parents": len(rec.parents) if rec.found else 0,
            "parent_ids": ", ".join(p["req_id"] for p in rec.parents) if rec.found else "",
            "is_top_level": rec.found and not any(
                registry.get(p["req_id"]) and registry[p["req_id"]].found for p in rec.parents
            ),
            "verification_comments": (rec.verification_comments or "")[:300],
        })
    return rows


MASTER_COLUMNS = [
    ("req_id", "Req. ID", 20),
    ("effective_status_label", "Effective Status", 18),
    ("found", "Loaded?", 9),
    ("own_compliance_status", "Compliance Status", 12),
    ("own_closeout_status", "Close-Out Status (own)", 16),
    ("vll", "Verified Lower Level", 12),
    ("suggestion", "Suggested Action", 55),
    ("num_direct_children", "# Direct Children", 11),
    ("num_descendants", "# Total Descendants", 12),
    ("num_open_descendants", "# Open Descendants", 12),
    ("num_missing_descendants", "# Missing Descendants", 13),
    ("num_parents", "# Parents", 9),
    ("parent_ids", "Parent Req IDs", 30),
    ("open_descendant_ids", "Open Descendant Req IDs", 40),
    ("open_descendant_details", "Open Descendant Details (ID | Compliance | Close-Out | Text)", 70),
    ("closed_descendant_details", "Closed Descendant Details (direct)", 60),
    ("pending_descendant_details", "Pending Descendant Details (deep)", 70),
    ("missing_descendant_ids", "Missing/External Descendant Req IDs", 40),
    ("reason", "Reason / Explanation", 60),
    ("verification_stage", "Verification Stage", 16),
    ("verification_method", "Verification Method", 16),
    ("test_proc_id", "Test Proc ID", 14),
    ("source_file", "Source File", 16),
    ("source_sheet", "Source Sheet", 14),
    ("source_row", "Source Row", 10),
    ("req_text", "Requirement Text", 70),
    ("verification_comments", "Verification Comments", 50),
]


def _write_table(wb, sheet_name, rows, columns, title=None, status_col_key="effective_status_key"):
    ws = wb.create_sheet(sheet_name)
    start_row = 1
    if title:
        ws.cell(row=1, column=1, value=title).font = TITLE_FONT
        ws.row_dimensions[1].height = 22
        start_row = 3

    header_row = start_row
    for col_idx, (key, label, width) in enumerate(columns, 1):
        ws.cell(row=header_row, column=col_idx, value=label)
    _style_header_row(ws, row=header_row, ncols=len(columns))
    _autosize(ws, [w for _, _, w in columns])

    status_col_idx = None
    for idx, (key, _, _) in enumerate(columns, 1):
        if key == "effective_status_label":
            status_col_idx = idx

    for r_offset, row in enumerate(rows, start=1):
        excel_row = header_row + r_offset
        for col_idx, (key, _, _) in enumerate(columns, 1):
            val = row.get(key, "")
            if isinstance(val, bool):
                val = "Yes" if val else "No"
            cell = ws.cell(row=excel_row, column=col_idx, value=val)
            cell.font = BASE_FONT
            cell.alignment = Alignment(vertical="top", wrap_text=(key in (
                "reason", "req_text", "verification_comments",
                "open_descendant_ids", "missing_descendant_ids", "parent_ids",
                "suggestion", "open_descendant_details",
                "closed_descendant_details", "pending_descendant_details"
            )))
            cell.border = THIN_BORDER
        if status_col_idx:
            status_key = row.get(status_col_key)
            fill, font = _status_fill_font(status_key)
            cell = ws.cell(row=excel_row, column=status_col_idx)
            cell.fill = fill
            cell.font = font

    last_row = header_row + len(rows)
    last_col = len(columns)
    if rows:
        ws.auto_filter.ref = f"A{header_row}:{get_column_letter(last_col)}{last_row}"
    return ws, header_row, last_row


def build_dashboard(wb, registry, nodes, load_log, missing_refs):
    ws = wb.create_sheet("Dashboard", 0)
    ws.sheet_view.showGridLines = False

    ws.cell(row=1, column=1, value="EPS-SG / PDAP Requirement Trace Database").font = TITLE_FONT
    ws.cell(row=2, column=1, value="Auto-generated master verification trace — Open vs Closed rollup across all loaded VCD modules").font = SUBTITLE_FONT
    ws.row_dimensions[1].height = 26

    counts = {}
    for n in nodes.values():
        counts[n.effective_status] = counts.get(n.effective_status, 0) + 1
    total = len(nodes)
    loaded = sum(1 for r in registry.values() if r.found)
    missing = total - loaded

    summary_rows = [
        ("Total requirements referenced (loaded + external)", total),
        ("Requirements actually loaded from source files", loaded),
        ("Requirements referenced but NOT yet loaded (external/missing)", missing),
        ("", ""),
        ("Effectively Closed", counts.get(EFFECTIVE_CLOSED, 0)),
        ("Effectively Open", counts.get(EFFECTIVE_OPEN, 0)),
        ("Open — Pending Data (VLL blocked by missing children)", counts.get(EFFECTIVE_PENDING_DATA, 0)),
        ("External / Not Loaded", counts.get(EFFECTIVE_EXTERNAL, 0)),
        ("Unverified (no status recorded)", counts.get(EFFECTIVE_UNVERIFIED, 0)),
    ]

    row = 4
    ws.cell(row=row, column=1, value="Summary").font = BOLD_FONT
    row += 1
    for label, value in summary_rows:
        ws.cell(row=row, column=1, value=label).font = BASE_FONT
        c = ws.cell(row=row, column=2, value=value)
        c.font = BOLD_FONT
        c.alignment = Alignment(horizontal="right")
        row += 1

    row += 1
    ws.cell(row=row, column=1, value="How to refresh this database").font = BOLD_FONT
    row += 1
    instructions = [
        "1. Drop new or updated requirement .xlsx files into your input folder (any filename works).",
        "2. Re-run:  python build_workbook.py <input_folder> <output_xlsx_path>",
        "3. Re-open the regenerated file -- all sheets, statuses, and Search formulas rebuild automatically.",
    ]
    for instr in instructions:
        ws.cell(row=row, column=1, value=instr).font = Font(name=FONT_NAME, size=9, italic=True, color="444444")
        row += 1

    row += 1
    ws.cell(row=row, column=1, value="Top-Level Requirements (no parent / root level)").font = BOLD_FONT
    row += 1
    top_level = find_top_level_requirements(registry)
    headers = ["Req. ID", "Effective Status", "Compliance", "Reason"]
    for i, h in enumerate(headers, 1):
        ws.cell(row=row, column=i, value=h)
    _style_header_row(ws, row=row, ncols=4)
    header_row_idx = row
    row += 1
    for rid in sorted(top_level):
        n = nodes[rid]
        ws.cell(row=row, column=1, value=rid).font = BASE_FONT
        status_cell = ws.cell(row=row, column=2, value=STATUS_LABELS.get(n.effective_status, n.effective_status))
        fill, font = _status_fill_font(n.effective_status)
        status_cell.fill = fill
        status_cell.font = font
        ws.cell(row=row, column=3, value=n.effective_compliance or "").font = BASE_FONT
        rc = ws.cell(row=row, column=4, value=n.reason)
        rc.font = BASE_FONT
        rc.alignment = Alignment(wrap_text=True, vertical="top")
        row += 1

    if top_level:
        ws.auto_filter.ref = f"A{header_row_idx}:D{row-1}"

    _autosize(ws, [55, 20, 14, 80])
    ws.column_dimensions["A"].width = 55
    return ws


def build_load_log_sheet(wb, load_log, unmapped_headers, missing_refs):
    ws = wb.create_sheet("Load_Log")
    ws.cell(row=1, column=1, value="File Load Log").font = TITLE_FONT
    headers = ["File", "Sheet", "Status", "Rows Loaded"]
    for i, h in enumerate(headers, 1):
        ws.cell(row=3, column=i, value=h)
    _style_header_row(ws, row=3, ncols=4)
    row = 4
    for entry in load_log:
        ws.cell(row=row, column=1, value=entry.get("file", "")).font = BASE_FONT
        ws.cell(row=row, column=2, value=entry.get("sheet", "")).font = BASE_FONT
        ws.cell(row=row, column=3, value=entry.get("status", "")).font = BASE_FONT
        ws.cell(row=row, column=4, value=entry.get("rows_loaded", "")).font = BASE_FONT
        row += 1

    row += 2
    ws.cell(row=row, column=1, value="Unrecognized Columns (ignored — review if important data is being skipped)").font = BOLD_FONT
    row += 1
    headers2 = ["File", "Sheet", "Column Index", "Header Text"]
    for i, h in enumerate(headers2, 1):
        ws.cell(row=row, column=i, value=h)
    _style_header_row(ws, row=row, ncols=4)
    row += 1
    for (fname, sheet), cols in unmapped_headers.items():
        for col_idx, header_text in cols:
            ws.cell(row=row, column=1, value=fname).font = BASE_FONT
            ws.cell(row=row, column=2, value=sheet).font = BASE_FONT
            ws.cell(row=row, column=3, value=col_idx + 1).font = BASE_FONT
            ws.cell(row=row, column=4, value=str(header_text)).font = BASE_FONT
            row += 1

    _autosize(ws, [22, 16, 60, 14])
    return ws


def build_missing_refs_sheet(wb, missing_refs):
    ws = wb.create_sheet("Missing_Refs")
    ws.cell(row=1, column=1, value="Referenced but Not Yet Loaded (External / Missing Requirements)").font = TITLE_FONT
    ws.cell(row=2, column=1, value="Add the source module containing these Req IDs to your input folder, then re-run, to extend the trace further down.").font = SUBTITLE_FONT
    headers = ["Missing Req. ID", "Module Tag (as referenced)", "Referenced From (Req. ID)"]
    row = 4
    for i, h in enumerate(headers, 1):
        ws.cell(row=row, column=i, value=h)
    _style_header_row(ws, row=row, ncols=3)
    header_row = row
    row += 1
    for referencing, missing_id, module in sorted(missing_refs, key=lambda x: x[1]):
        ws.cell(row=row, column=1, value=missing_id).font = BASE_FONT
        ws.cell(row=row, column=2, value=module).font = BASE_FONT
        ws.cell(row=row, column=3, value=referencing).font = BASE_FONT
        row += 1
    if missing_refs:
        ws.auto_filter.ref = f"A{header_row}:C{row-1}"
    _autosize(ws, [26, 30, 26])
    return ws


def build_trace_chain_sheet(wb, registry, nodes):
    """One row per ancestor->descendant edge across the FULL depth of the tree."""
    ws = wb.create_sheet("Trace_Chain")
    ws.cell(row=1, column=1, value="Full Depth Trace Chain (every ancestor -> every descendant)").font = TITLE_FONT
    headers = ["Top/Ancestor Req. ID", "Descendant Req. ID", "Relationship Depth", "Descendant Effective Status", "Descendant Loaded?"]
    row = 3
    for i, h in enumerate(headers, 1):
        ws.cell(row=row, column=i, value=h)
    _style_header_row(ws, row=row, ncols=len(headers))
    header_row = row
    row += 1

    def walk(req_id, depth, seen):
        nonlocal row
        if req_id in seen:
            return
        seen = seen | {req_id}
        rec = registry.get(req_id)
        if rec is None or not rec.found:
            return
        for child in rec.children_snapshot:
            cid = child["req_id"]
            cnode = nodes.get(cid)
            ws.cell(row=row, column=1, value=req_id).font = BASE_FONT
            ws.cell(row=row, column=2, value=cid).font = BASE_FONT
            ws.cell(row=row, column=3, value=depth).font = BASE_FONT
            status_label = STATUS_LABELS.get(cnode.effective_status, "") if cnode else ""
            scell = ws.cell(row=row, column=4, value=status_label)
            if cnode:
                fill, font = _status_fill_font(cnode.effective_status)
                scell.fill = fill
                scell.font = font
            crec = registry.get(cid)
            ws.cell(row=row, column=5, value="Yes" if (crec and crec.found) else "No").font = BASE_FONT
            row += 1
            walk(cid, depth + 1, seen)

    top_level = find_top_level_requirements(registry)
    for rid in sorted(top_level):
        walk(rid, 1, set())

    if row > header_row + 1:
        ws.auto_filter.ref = f"A{header_row}:E{row-1}"
    _autosize(ws, [22, 26, 16, 22, 14])
    return ws


def build_suggestions_sheet(wb, registry, nodes):
    """One row per requirement that has an actionable closure suggestion."""
    ws = wb.create_sheet("Suggestions")
    ws.cell(row=1, column=1, value="Closure Suggestions - actionable next steps to close requirements").font = TITLE_FONT
    ws.cell(row=2, column=1, value="Generated from VLL (Verified Lower Level) rollup and lower-level status. Review before acting.").font = SUBTITLE_FONT
    headers = ["Req. ID", "Effective Status", "Compliance", "Close-Out", "VLL", "Suggested Action"]
    row = 4
    for i, h in enumerate(headers, 1):
        ws.cell(row=row, column=i, value=h)
    _style_header_row(ws, row=row, ncols=len(headers))
    header_row = row
    row += 1

    count = 0
    for req_id, rec in sorted(registry.items()):
        if not rec.found:
            continue
        suggestion = make_closure_suggestion(req_id, registry, nodes)
        if not suggestion:
            continue
        node = nodes[req_id]
        ws.cell(row=row, column=1, value=req_id).font = BASE_FONT
        scell = ws.cell(row=row, column=2, value=STATUS_LABELS.get(node.effective_status, node.effective_status))
        fill, font = _status_fill_font(node.effective_status)
        scell.fill, scell.font = fill, font
        ws.cell(row=row, column=3, value=rec.compliance_status or "").font = BASE_FONT
        ws.cell(row=row, column=4, value=rec.closeout_status or "").font = BASE_FONT
        ws.cell(row=row, column=5, value="Yes" if rec.vll is True else ("No" if rec.vll is False else "")).font = BASE_FONT
        sc = ws.cell(row=row, column=6, value=suggestion)
        sc.font = BASE_FONT
        sc.alignment = Alignment(wrap_text=True, vertical="top")
        row += 1
        count += 1

    if count == 0:
        ws.cell(row=row, column=1, value="No closure suggestions - nothing is currently closable or flagged.").font = BASE_FONT
    else:
        ws.auto_filter.ref = f"A{header_row}:F{row-1}"
    _autosize(ws, [20, 18, 12, 12, 8, 90])
    return ws


def build_open_descendant_details_sheet(wb, registry, nodes):
    """One row per (parent requirement, open descendant) pair, with full text + status."""
    ws = wb.create_sheet("Open_Descendant_Details")
    ws.cell(row=1, column=1, value="Open Descendant Details - every open lower-level requirement, per parent").font = TITLE_FONT
    ws.cell(row=2, column=1, value="Use this to see exactly which lower-level requirements keep a parent open, with their text so an engineer can action them.").font = SUBTITLE_FONT
    headers = ["Parent Req. ID", "Open Descendant Req. ID", "Depth", "Compliance", "Close-Out",
               "Loaded?", "Descendant Requirement Text"]
    row = 4
    for i, h in enumerate(headers, 1):
        ws.cell(row=row, column=i, value=h)
    _style_header_row(ws, row=row, ncols=len(headers))
    header_row = row
    row += 1

    count = 0
    for req_id, rec in sorted(registry.items()):
        if not rec.found:
            continue
        opens = collect_pending_descendants_deep(req_id, registry, nodes)
        for d in opens:
            ws.cell(row=row, column=1, value=req_id).font = BASE_FONT
            ws.cell(row=row, column=2, value=d["req_id"]).font = BASE_FONT
            ws.cell(row=row, column=3, value=d["depth"]).font = BASE_FONT
            ws.cell(row=row, column=4, value=d["compliance_status"] or "").font = BASE_FONT
            ws.cell(row=row, column=5, value=d["closeout_status"] or "").font = BASE_FONT
            ws.cell(row=row, column=6, value="Yes" if d["found"] else "No").font = BASE_FONT
            tcell = ws.cell(row=row, column=7, value=(d["req_text"] or "").strip())
            tcell.font = BASE_FONT
            tcell.alignment = Alignment(wrap_text=True, vertical="top")
            row += 1
            count += 1

    if count == 0:
        ws.cell(row=row, column=1, value="No open descendants across all loaded requirements.").font = BASE_FONT
    else:
        ws.auto_filter.ref = f"A{header_row}:G{row-1}"
    _autosize(ws, [20, 24, 8, 12, 12, 9, 80])
    return ws

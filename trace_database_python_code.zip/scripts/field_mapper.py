"""
field_mapper.py
Fuzzy header-to-canonical-field mapping for DOORS-exported VCD spreadsheets.

Different DOORS module exports use different literal header text for the same
logical field (e.g. "Verified Lower Level" vs "isVLL"). This module maps any
observed header to one of a fixed set of canonical field names using
substring/keyword rules, ordered from most specific to least specific.

Canonical fields produced (a row's dict may be missing keys it doesn't have):
    req_id              - clean requirement identifier (no version suffix)
    req_id_raw           - the raw value of the FIRST "Req. ID"-like column (may carry version)
    req_text             - requirement narrative text (#Req. Info / Requirements)
    uptrace_raw          - DXL_Uptrace raw text (parent links)
    ll_closeout_raw       - "LL Close-Out Summary" raw text (child links + per-child status)
    local_compliance_raw - "Local Compliance Summary" raw text
    vll                  - Verified Lower Level flag, normalized to True/False/None
    verification_stage
    verification_level
    verification_method
    verification_status
    test_proc_id
    test_proc_name
    compliance_status     - canonical current compliance status (C/PC/CS/NC/...)
    closeout_status        - canonical current close-out status (OPEN/CLOSED)
    absolute_number
    verification_comments
    vcb_comments
    verification_report_ref
    object_level
    module_hint            - filename or detected module tag, used as fallback module label
"""

import re

# Ordered rules: (canonical_field, [substrings to match in lowercased header]).
# First matching rule wins for a given header. More specific rules are listed first.
HEADER_RULES = [
    ("vll", ["verified lower level", "isvll", "vll"]),
    ("test_proc_name", ["test proc name", "test spec name"]),
    ("test_proc_id", ["test proc id", "test spec id", "tpro"]),
    ("verification_stage", ["verification stage"]),
    ("verification_level", ["verification level"]),
    ("verification_method", ["verification method", "v. method", "verif method"]),
    # Abbreviated status headers seen in some exports:
    #   "C. Status" = Compliance Status, "V. Status" = Verification Status,
    #   "CO Status" / "C-O Status" = Close-Out Status
    ("closeout_status", ["close-out status", "close out status", "closeout status",
                          "co status", "co. status", "c-o status", "c.o status", "c.o. status"]),
    ("verification_status", ["verification status", "v. status", "v status", "verif status"]),
    ("verification_comments", ["verification comment", "v. comment"]),
    ("vcb_comments", ["vcb comment"]),
    ("verification_report_ref", ["verification report reference", "verif report"]),
    ("local_compliance_raw", ["local compliance summary"]),
    ("ll_closeout_raw", ["ll close-out summary", "ll close out summary", "ll closeout"]),
    ("compliance_status", ["dxl_compliance_status", "compliance status",
                            "c. status", "c status", "compl status", "compl. status"]),
    ("uptrace_raw", ["dxl_uptrace", "uptrace"]),
    ("object_level", ["object level"]),
    ("absolute_number", ["absolute number"]),
    ("req_text", ["#req. info", "req. info", "req info", "requirements", "requirement text"]),
    # req_id matched last among "id"-like so more specific module/MBSE id columns
    # are still captured, but plain "Req. ID" / "Req ID" is the canonical one.
    ("req_id", ["req. id", "req id", "requirement id", "reqid"]),
]

# Columns we deliberately ignore (noise / DOORS export artifacts)
IGNORE_HEADER_SUBSTRINGS = [":noexport", "rfd/rfw", "mbse-334", "stage@tranchelevel"]


def normalize_header(header):
    if header is None:
        return ""
    return str(header).strip().lower()


def classify_header(header):
    """Return canonical field name for a header, or None if unrecognized/ignored."""
    h = normalize_header(header)
    if not h:
        return None
    for ignore in IGNORE_HEADER_SUBSTRINGS:
        if ignore in h:
            return None
    for field, keywords in HEADER_RULES:
        for kw in keywords:
            if kw in h:
                return field
    return None


def build_column_map(header_row):
    """
    Given a list of header values (row 1 of a sheet), return:
      mapping: dict canonical_field -> list of 0-based column indices (in header order)
      unmapped: list of (col_idx, header_text) not recognized

    Some canonical fields legitimately appear more than once in a single DOORS
    export (e.g. "Req. ID" appears twice: once with version suffix, once clean;
    "Test Proc ID" appears twice). We keep ALL matching column indices in order
    of appearance so the row-extraction step can apply precedence rules.
    """
    mapping = {}
    unmapped = []
    for idx, header in enumerate(header_row):
        field = classify_header(header)
        if field is None:
            if header is not None and str(header).strip():
                unmapped.append((idx, header))
            continue
        mapping.setdefault(field, []).append(idx)
    return mapping, unmapped


def pick_req_id_value(row_values, req_id_cols):
    """
    Among all columns classified as 'req_id', prefer the one whose value does
    NOT contain a version suffix like '(v2A)' -- that is the clean ID DOORS
    uses for cross-references. Falls back to the first non-empty value,
    stripped of any trailing '(...)' version marker.
    """
    candidates = []
    for c in req_id_cols:
        if c < len(row_values):
            v = row_values[c]
            if v is not None and str(v).strip():
                candidates.append(str(v).strip())
    if not candidates:
        return None
    clean = [c for c in candidates if "(" not in c]
    chosen = clean[0] if clean else candidates[0]
    return strip_version_suffix(chosen)


def strip_version_suffix(req_id):
    """Remove DOORS version markers like ' (v2A)' or ' (v1D)' from an ID string."""
    if req_id is None:
        return None
    return re.sub(r"\s*\(v[^)]*\)\s*$", "", str(req_id).strip())


# A token that "looks like" a requirement ID: starts with a letter, contains at
# least one hyphen/dot/underscore separator, has digits somewhere, no spaces.
REQ_ID_TOKEN_RE = re.compile(r'^[A-Za-z][A-Za-z0-9]*(?:[\-_.][A-Za-z0-9]+)+$')

# An embedded "[Module] ReqID" prefix possibly followed by requirement text on
# subsequent lines (a different DOORS export style, e.g. IRS MWI exports).
EMBEDDED_MODULE_ID_RE = re.compile(r'^\s*\[[^\]]+\]\s+(\S+)')


def looks_like_req_id(value):
    """True if a cell value looks like (or begins with) a requirement identifier."""
    if value is None:
        return False
    s = str(value).strip()
    if not s or s.startswith("§"):
        return False
    # Case 1: the whole (first line of the) cell is a bare ID token.
    first_line = s.splitlines()[0].strip()
    if REQ_ID_TOKEN_RE.match(first_line):
        return True
    # Case 2: "[Module] ReqID ..." embedded style -> the token after the bracket
    m = EMBEDDED_MODULE_ID_RE.match(s)
    if m and REQ_ID_TOKEN_RE.match(m.group(1)):
        return True
    return False


def extract_req_id_from_cell(value):
    """
    Pull a clean requirement ID out of a cell that may be either a bare ID, an
    ID with a version suffix, or an embedded "[Module] ReqID\\n<text>" block.
    Returns (req_id, embedded_text_or_None).
    """
    if value is None:
        return None, None
    s = str(value).strip()
    if not s:
        return None, None

    lines = s.splitlines()
    first_line = lines[0].strip()

    # Embedded "[Module] ReqID" style: capture ID + treat remaining lines as text
    m = EMBEDDED_MODULE_ID_RE.match(first_line)
    if m and REQ_ID_TOKEN_RE.match(m.group(1)):
        req_id = strip_version_suffix(m.group(1))
        text = "\n".join(lines[1:]).strip() if len(lines) > 1 else None
        return req_id, text

    # Bare ID token on the first line
    bare = strip_version_suffix(first_line)
    if bare and REQ_ID_TOKEN_RE.match(bare):
        text = "\n".join(lines[1:]).strip() if len(lines) > 1 else None
        return bare, text

    return None, None


def detect_req_id_column_by_content(sheet_rows, max_scan_rows=40):
    """
    When no header maps to req_id, infer the Req ID column from cell CONTENT.
    sheet_rows: list of rows, each a list of cell values (including header row 0).
    Returns the 0-based column index whose data cells most consistently look
    like requirement IDs, or None if no column qualifies.
    """
    if not sheet_rows or len(sheet_rows) < 2:
        return None
    ncols = max(len(r) for r in sheet_rows)
    best_col = None
    best_score = 0.0
    for col in range(ncols):
        hits = 0
        total = 0
        for row in sheet_rows[1:max_scan_rows + 1]:
            if col >= len(row):
                continue
            val = row[col]
            if val is None or str(val).strip() == "":
                continue
            total += 1
            if looks_like_req_id(val):
                hits += 1
        if total == 0:
            continue
        score = hits / total
        # Require a strong majority to avoid false positives on e.g. test-proc-id columns
        if score >= 0.6 and hits >= 2 and score > best_score:
            best_score = score
            best_col = col
    return best_col


def extract_row_fields(header_row, row_values):
    """
    Given the header row and a single data row's values, return a dict of
    canonical_field -> value, applying precedence rules for duplicate columns.
    """
    mapping, _unmapped = build_column_map(header_row)
    out = {}

    if "req_id" in mapping:
        out["req_id"] = pick_req_id_value(row_values, mapping["req_id"])

    for field, cols in mapping.items():
        if field == "req_id":
            continue
        # take first non-empty value among columns mapped to this field
        val = None
        for c in cols:
            if c < len(row_values) and row_values[c] is not None and str(row_values[c]).strip() != "":
                val = row_values[c]
                break
        out[field] = val

    return out

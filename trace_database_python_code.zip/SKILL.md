---
name: trace-database
description: >
  Builds a master Verification/Requirement Trace Database from DOORS-exported
  VCD Excel files. Auto-discovers any .xlsx requirement module in a folder,
  fuzzy-maps differing headers (Req. ID, DXL_Uptrace, LL Close-Out Summary,
  Verified Lower Level / isVLL, Compliance Status, Close-Out Status) to one
  schema, parses embedded child-link text blocks, and recursively rolls up
  Open/Closed/Pending status from leaf requirements up to top-level system
  requirements. ALWAYS use whenever the user mentions trace database, VCD,
  requirement trace, V&V/IVV traceability, DXL_Uptrace, LL Close-Out Summary,
  Verified Lower Level, VLL, isVLL, compliance roll-up, open/closed status and
  why, requirement impact analysis, or uploads multiple requirement/VCD .xlsx
  files together. Produces a multi-sheet workbook (Dashboard, Master_Trace,
  Search with live formulas, Open_Items, Closed_Items, Trace_Chain,
  Missing_Refs, Load_Log). Trigger even on casual phrasing like "build me a
  trace database" without naming specific columns.
---

# Trace Database

Builds a master requirement verification trace database from one or more
DOORS-exported VCD (Verification Control Document) Excel files, recursively
rolling up Open/Closed status from the lowest loaded requirement level up to
the top, and produces a single multi-sheet Excel workbook an engineer can
browse, filter, and search.

## When this skill applies

Use this skill whenever the person:
- Uploads two or more requirement/VCD `.xlsx` files together (different DOORS
  modules, e.g. SRD, OGSRD, PDAPRD), or a single VCD file and asks for trace
  analysis on it.
- Mentions any of: trace database, VCD, DXL_Uptrace, "LL Close-Out Summary",
  Verified Lower Level / VLL / isVLL, requirement compliance roll-up,
  open/closed requirement analysis, impact analysis on requirements.
- Asks "what's open and why", "what's blocking closure of requirement X",
  "show me the full trace for X from top to bottom", or similar.

This is **not** a generic spreadsheet-cleanup task — it specifically
understands DOORS-style requirement export structure. Read this whole
SKILL.md before writing any code; the column-mapping and status-rollup
business rules below are not obvious from the spreadsheet alone and getting
them wrong produces a misleading trace.

## The domain, in brief

Each row in a VCD export is one requirement. Two free-text columns carry the
actual trace relationships, encoded as DOORS reference text — not normal
structured columns:

- **DXL_Uptrace**: the requirement's PARENT links, one per line, formatted
  `[ModuleName] ParentReqID`. E.g. `[EURD] SYS-00020`.
- **LL Close-Out Summary**: the requirement's CHILD links, one per line,
  formatted `[ModuleName] ChildReqID: 'ComplianceStatus', 'CloseOutStatus'`.
  E.g. `[OGSRD] GS-SYS-00120: 'PC', 'OPEN'`. This is a cached snapshot of the
  child's status *as recorded at the parent* — when the child's own module is
  loaded, that module's own row is authoritative instead.
- A `'Compliance Status'` column holds the requirement's own current
  compliance code: `C` (Compliant), `PC` (Partially Compliant), `CS`
  (Compliant for Stage), `NC`, `NS`, etc.
- A `'Close-Out Status'` column holds `Open` or `Closed`.
- A **Verified Lower Level** (sometimes named `isVLL`) flag of `Yes` means
  the requirement's status is *purely* a function of its children — not its
  own recorded compliance/close-out fields.

Different DOORS module exports use different literal header text for the
same logical field (e.g. `Verified Lower Level` vs `isVLL`; abbreviated forms
like `C. Status` for Compliance Status, `V. Status` for Verification Status,
`CO Status` for Close-Out Status; or a module having two different "Req. ID"
columns — one with a version suffix like `(v2A)` and one without). Some
exports don't have a recognizable "Req. ID" header at all — the ID is embedded
in an object-text column as `[Module Name] R-MWI-0010` followed by the
requirement text on the next lines. **Never assume a fixed header layout.**
Always run the fuzzy header mapper (see Workflow); if no header maps to a
Req ID, the pipeline automatically falls back to detecting the Req ID column
by CONTENT (scanning which column's cells look like requirement identifiers)
and to extracting the ID from the embedded `[Module] ID` prefix. This is the
single most important rule for this skill, since every new module the user
adds will likely have yet another header variant.

## Business rules for status roll-up (do not deviate from these)

1. **If VLL/isVLL = Yes**: the requirement's effective status is determined
   *entirely* by its children, recursively. Its own Compliance/Close-Out
   Status fields are ignored for rollup purposes (still shown for reference).
   - All children effectively Closed -> requirement is Closed.
   - Any child still Open -> requirement is Open.
   - Any child not yet loaded (see rule 3) -> requirement is
     **"Open - Pending Data"**, never assumed Closed.
2. **If VLL/isVLL = No or unset**: the requirement's own Close-Out Status is
   authoritative for whether it's Open/Closed, but the children explain
   *why*. A requirement showing compliance `CS` (Compliant for Stage) while
   Open typically means some, but not all, of its lower-level requirements
   have closed — surface this explicitly in the explanation text, don't just
   report the raw status code.
3. **External/Missing children**: if a child Req ID referenced in
   `LL Close-Out Summary` (or a parent referenced in `DXL_Uptrace`) does not
   exist in ANY loaded source file, it is genuinely unknown — not yet
   uploaded. Mark it `External / Not Loaded` and treat it as inconclusive,
   never as silently Closed or silently ignored. This is expected and normal
   — VCD exports are usually loaded incrementally as more modules become
   available — so report it informatively, not as an error.
4. **Module identity comes from the `[ModuleName]` tag in the text, not from
   the source filename.** The person will drop files into one folder with
   arbitrary names; the tool must auto-discover and cross-link purely by
   Req ID regardless of which file a row physically lives in.
5. **Cycles** (A traces to B traces to A) must be detected and broken safely
   (treat as Open, flag it) rather than infinite-looping.

## Workflow

1. **Locate the input folder.** If the person uploaded files directly, copy
   them into one working folder (e.g. `/home/claude/trace_input/`) — do not
   rely on original upload filenames meaning anything semantically.
2. **Run the pipeline** from `scripts/`:
   ```bash
   python3 scripts/build_workbook.py <input_folder> <output_xlsx_path>
   ```
   This single command does everything: fuzzy header detection, parsing of
   `DXL_Uptrace`/`LL Close-Out Summary` blocks, recursive status rollup, and
   writing the full multi-sheet Excel workbook.
3. **Recalculate formulas and check for errors** (the Search sheet uses
   live INDEX/MATCH formulas):
   ```bash
   python3 scripts/recalc.py <output_xlsx_path> 60
   ```
   If `total_errors` is not 0, investigate before delivering — see
   `references/troubleshooting.md`.
4. **Sanity-check the output** before presenting it: open the Dashboard
   sheet and spot-check 2-3 requirements against their source row by hand
   (see `references/validation_checklist.md`) — this catches header-mapping
   misses early, since a fuzzy mapper can silently miss a renamed column.
5. **Present the file** via `present_files`. Briefly summarize counts (total
   loaded, total external/missing, open vs closed) in your reply — don't
   just hand over the file with no context.
6. **When the person adds more requirement modules later** (e.g. leaf-level
   modules that are currently showing as "External / Not Loaded"), simply
   re-run step 2 with the expanded folder — the tool is fully dynamic and
   needs no reconfiguration. Tell the person this explicitly so they know
   the workflow scales as they get more source files.

## Output workbook structure

| Sheet | Purpose |
|---|---|
| `Dashboard` | Summary counts, refresh instructions, top-level requirement list with reasons |
| `Search` | Type/pick a Req ID -> full card of every field via live formulas, including a Suggested Action, a Closed Descendants (direct) block and an Open/Pending Descendants (deep) block each showing ID \| Compliance \| Close-Out \| Text; plus a quick text filter |
| `Master_Trace` | One row per requirement: effective status, compliance, parents, descendants, suggested action, open-descendant detail, full reasoning text |
| `Open_Items` | Filtered to everything not effectively Closed (includes Open and External/Missing) |
| `Closed_Items` | Filtered to everything effectively Closed, full chain context |
| `Suggestions` | One row per requirement with an actionable closure suggestion (e.g. VLL=Yes parent whose children are all closed -> can be promoted to Compliant/Closed) |
| `Open_Descendant_Details` | One row per (parent, pending descendant) with the descendant's own text + status, for filtering exactly what keeps each parent open |
| `Trace_Chain` | One row per ancestor->descendant edge at every depth, for full top-to-bottom traceability |
| `Missing_Refs` | Every externally-referenced-but-not-loaded Req ID, who references it, and its module tag — tells the person exactly what to upload next |
| `Load_Log` | Which files/sheets were read, row counts, any unrecognized columns, and any Req ID columns that had to be inferred from content |

## Why no VBA / .xlsm macros

This environment is Linux-based with no Windows Excel and no network access
to OLE-authoring libraries, so a hand-built `vbaProject.bin` binary cannot be
reliably constructed or verified here — a single wrong byte can silently
corrupt the workbook. **Do not attempt to fabricate a `.xlsm` with an
embedded macro.** Instead:
- Ship a plain `.xlsx` with all interactivity built from native Excel
  formulas, data validation dropdowns, and AutoFilter (works in every Excel
  version, no macro security prompts).
- The Dashboard sheet's "How to refresh" panel gives the person the exact
  command to re-run as new data arrives.
- If the person specifically wants VBA code to paste in themselves (e.g. a
  one-click refresh button), see `references/optional_vba_module.md` for a
  ready-to-import `.bas` module they can add via Alt+F11 -> Import File in
  their own Excel — this is safe because *they* compile it locally in their
  own trusted Excel instance rather than Claude shipping an opaque binary.

## Reference files

- `references/field_mapping_rules.md` — the exact fuzzy-matching keyword
  table used to map arbitrary DOORS headers to canonical fields; consult
  this before editing `scripts/field_mapper.py` or if a new module's headers
  aren't being recognized.
- `references/validation_checklist.md` — manual spot-check steps to run
  before delivering output.
- `references/troubleshooting.md` — common failure modes (duplicate Req
  IDs across files, headers not matching, formula errors after recalc) and
  fixes.
- `references/optional_vba_module.md` — VBA `.bas` source the person can
  self-import for a one-click refresh button, with exact import steps.
